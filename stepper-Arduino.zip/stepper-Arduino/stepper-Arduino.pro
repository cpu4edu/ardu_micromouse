EAGLE AutoRouter Statistics:

Job           : D:/My document/eagle/StepperMouse-Arduino/stepper-Arduino-min.brd

Start at      : 16:54:30 (2011/04/28)
End at        : 16:54:30 (2011/04/28)
Elapsed time  : 00:00:00

Signals       :    43   RoutingGrid: 50 mil  Layers: 2
Connections   :    97   predefined:  88 ( 9 Vias )

Router memory :   13800

Passname          :    Busses     Route Optimize1 Optimize2 Optimize3 Optimize4

Time per pass     :  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00
Number of Ripups  :         0         0         0         0         0         0
max. Level        :         0         0         0         0         0         0
max. Total        :         0         0         0         0         0         0

Routed            :         0         0         0         0         0         0
Vias              :         0         0         0         0         0         0
Resolution        :    90.7 %    90.7 %    90.7 %    90.7 %    90.7 %    90.7 %

Final             : 90.7% finished
